<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Benvingut al Configurador de Hosting</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Pagina d'inici</h1>
    <p><a href="register.php">Registrar-se</a> | <a href="login.php">Iniciar Sessió</a></p>
</body>
</html>

